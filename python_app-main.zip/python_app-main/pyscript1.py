num1 = input('Enter Number\n');

num2 = input('Enter another number \n')

num3 = input('Enter another number')
"""
if num1 > num2 and num1 > num3 :
    print(num1+' is the greater number')
elif num2 > num1 and num2 > num3 :
    print(num2+" is greater")
else :
    print(num3 +' is greater value') 
   """
# membership operator in and not in
nums=[10,20,30,40]
a = 10
print(a not in nums) 

nums1 = [10,20,30,40]

print(nums == nums1)  